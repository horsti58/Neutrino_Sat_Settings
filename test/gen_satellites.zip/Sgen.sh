#!/bin/sh
# DESCRIPTION=This script generates satellites.gen (own satellites.xml) backwards from services.xml
#
# prerequisites: libsxlt xsltproc
# genS.xsl lookupFEC.XML lookupMOD.XML in your working directory f.e /var/script/xsl/generate
# Sgen.sh the shell-script to generate result: satellites.gen in working directory
# services.xml expected in /var/tuxbox/config/zapit
#
# by /ME 19.12.2017
#
xsltproc -o satellites.gen genS.xsl /var/tuxbox/config/default/services.xml

